// 前端应用
const API_BASE = '/api';
let player = null;
let currentTab = 'hotboard';

async function api(path, options = {}) {
  try {
    const resp = await fetch(API_BASE + path, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...options.headers },
    });
    return await resp.json();
  } catch (e) {
    return { code: -1, msg: 'Network error: ' + e.message };
  }
}

function showToast(msg, type = 'info') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = 'toast show ' + type;
  setTimeout(() => { toast.className = 'toast'; }, 3000);
}

function formatTime(ts) {
  if (!ts) return '';
  const date = new Date(ts);
  const now = Date.now();
  const diff = now - ts;
  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前';
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前';
  if (diff < 7 * 86400000) return Math.floor(diff / 86400000) + '天前';
  return date.toLocaleDateString('zh-CN');
}

function formatDuration(s) {
  if (!s || s <= 0) return '';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${String(sec).padStart(2, '0')}`;
}

function escapeHtml(s) {
  if (!s) return '';
  return String(s).replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[m]));
}

function formatHot(n) {
  if (n >= 10000) return (n / 10000).toFixed(1) + '万';
  return String(n);
}

function renderPlayActions(item) {
  const hasAudio = !!item.audioUrl;
  const supportsTts = item.ttsEnabled !== false;
  
  return `
    <div class="play-actions" data-id="${escapeHtml(item.id)}" data-source="${escapeHtml(item.source)}">
      ${hasAudio ? `<button class="play-btn" data-action="play-audio" data-url="${escapeHtml(item.audioUrl)}">▶ 播放音频</button>` : ''}
      ${supportsTts ? `<button class="play-btn tts" data-action="play-tts">🔊 朗读</button>` : ''}
      <button class="play-btn add" data-action="add-playlist">+ 播放列表</button>
    </div>
  `;
}

function renderNewsItem(item, index, showPlayActions = true) {
  const rankClass = index !== undefined && index < 3 ? `top${index + 1}` : '';
  const rankHtml = index !== undefined ? `<span class="hot-rank ${rankClass}">${index + 1}</span>` : '';
  const hotHtml = item.hot ? `<span class="news-hot">🔥 ${formatHot(item.hot)}</span>` : '';
  const audioBadge = item.audioUrl ? `<span class="audio-badge">🎧 音频</span>` : '';
  const durationHtml = item.audioDuration ? `<span class="duration">⏱ ${formatDuration(item.audioDuration)}</span>` : '';
  
  return `
    <div class="news-item" data-id="${escapeHtml(item.id)}" data-source="${escapeHtml(item.source)}" data-url="${escapeHtml(item.url || '')}">
      <div class="news-meta">
        ${rankHtml}
        <span class="news-source">${escapeHtml(item.sourceName || item.source)}</span>
        ${audioBadge}
        <span>${formatTime(item.publishTime)}</span>
        ${durationHtml}
        ${hotHtml}
      </div>
      <div class="news-title">${escapeHtml(item.title)}</div>
      ${item.summary ? `<div class="news-summary">${escapeHtml(item.summary)}</div>` : ''}
      ${showPlayActions ? renderPlayActions(item) : ''}
    </div>
  `;
}

function attachNewsItemHandlers(container) {
  container.querySelectorAll('.news-item').forEach(el => {
    el.addEventListener('click', (e) => {
      // 点击播放按钮时不跳转
      if (e.target.closest('.play-actions')) return;
      
      const id = el.dataset.id;
      const source = el.dataset.source;
      const url = el.dataset.url;
      if (url) {
        window.open(url, '_blank');
      } else {
        showNewsDetail(source, id);
      }
    });
    
    // 播放操作
    el.querySelectorAll('.play-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const action = btn.dataset.action;
        const news = {
          id: el.dataset.id,
          source: el.dataset.source,
        };
        const playItem = collectItemFromEl(el);
        if (!playItem) return;
        
        if (action === 'play-audio') {
          player.setTtsMode('audio');
          player.setQueue([playItem], 0);
        } else if (action === 'play-tts') {
          player.setTtsMode('tts');
          player.setQueue([playItem], 0);
        } else if (action === 'add-playlist') {
          const result = await api('/player/playlist/add', {
            method: 'POST',
            body: JSON.stringify({ news: playItem }),
          });
          if (result.code === 0) {
            showToast(result.data?.message || '已添加', 'success');
            btn.classList.add('added');
            btn.textContent = '✓ 已添加';
          } else {
            showToast('添加失败: ' + result.msg, 'error');
          }
        }
      });
    });
  });
}

function collectItemFromEl(el) {
  const id = el.dataset.id;
  const source = el.dataset.source;
  const titleEl = el.querySelector('.news-title');
  const metaEl = el.querySelector('.news-meta');
  const summaryEl = el.querySelector('.news-summary');
  
  const sourceName = metaEl?.querySelector('.news-source')?.textContent || source;
  const audioBadge = metaEl?.querySelector('.audio-badge');
  
  return {
    id,
    source,
    sourceName,
    title: titleEl?.textContent || '',
    summary: summaryEl?.textContent || '',
    url: el.dataset.url || '',
    audioUrl: el.querySelector('.play-btn[data-action="play-audio"]')?.dataset.url || '',
  };
}

async function showNewsDetail(source, id) {
  const result = await api(`/news/detail?source_id=${source}&id=${encodeURIComponent(id)}`);
  if (result.code !== 0) {
    showToast(result.msg || '加载失败', 'error');
    return;
  }
  const data = result.data;
  const news = data.news || {};
  document.getElementById('detailTitle').textContent = news.title;
  document.getElementById('detailMeta').textContent = `${news.sourceName || news.source} · ${formatTime(news.publishTime)}`;
  document.getElementById('detailContent').textContent = data.content || news.summary || '暂无内容';
  const link = document.getElementById('detailLink');
  link.href = news.url || '#';
  document.getElementById('detailModal').classList.add('active');
}

// Tab 切换
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    currentTab = tab.dataset.tab;
    const panel = document.getElementById('panel-' + currentTab);
    if (panel) panel.classList.add('active');
    
    if (currentTab === 'hotboard') loadHotboard();
    if (currentTab === 'news') loadNewsPanel();
    if (currentTab === 'player') loadPlayableNews();
    if (currentTab === 'playlist') loadPlaylist();
    if (currentTab === 'sources') loadSourceList();
  });
});

// 关闭模态框
document.querySelector('.close').addEventListener('click', () => {
  document.getElementById('detailModal').classList.remove('active');
});
document.getElementById('detailModal').addEventListener('click', (e) => {
  if (e.target.id === 'detailModal') {
    document.getElementById('detailModal').classList.remove('active');
  }
});

// 热榜
async function loadHotboard() {
  const container = document.getElementById('hotboardList');
  const aggregate = document.getElementById('aggregateMode').checked;
  
  container.innerHTML = '<div class="empty">加载中...</div>';
  
  if (aggregate) {
    const result = await api('/aggregate/hotboard?limit=10');
    if (result.code !== 0) {
      container.innerHTML = `<div class="empty">${result.msg || '加载失败'}</div>`;
      return;
    }
    const groups = result.data || [];
    container.innerHTML = groups.map(group => {
      if (!group.news || group.news.length === 0) return '';
      return `
        <div class="hotboard-group">
          <h3>${escapeHtml(group.source)} 热榜</h3>
          <div class="news-list">
            ${group.news.map((item, i) => renderNewsItem(item, i)).join('')}
          </div>
        </div>
      `;
    }).join('');
    container.querySelectorAll('.hotboard-group').forEach(g => {
      attachNewsItemHandlers(g);
    });
  } else {
    const result = await api('/news/hotboard?source_id=baidu&limit=30');
    if (result.code !== 0) {
      container.innerHTML = `<div class="empty">${result.msg || '加载失败'}</div>`;
      return;
    }
    const news = (result.data && result.data.news) || [];
    if (news.length === 0) {
      container.innerHTML = '<div class="empty">暂无数据</div>';
      return;
    }
    container.innerHTML = news.map((item, i) => renderNewsItem(item, i)).join('');
    attachNewsItemHandlers(container);
  }
}

document.getElementById('aggregateMode').addEventListener('change', loadHotboard);

// 新闻面板
async function loadNewsPanel() {
  const sourcesResp = await api('/sources');
  const sources = sourcesResp.data || [];
  const sourceSelect = document.getElementById('newsSource');
  sourceSelect.innerHTML = sources.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join('');
  
  if (sources.length > 0) {
    sourceSelect.value = sources[0].id;
    await loadCategories(sources[0].id);
  }
  
  sourceSelect.addEventListener('change', () => loadCategories(sourceSelect.value));
}

async function loadCategories(sourceId) {
  const result = await api(`/news/categories?source_id=${sourceId}`);
  const select = document.getElementById('newsCategory');
  if (result.code !== 0 || !result.data) {
    select.innerHTML = '<option value="">无分类</option>';
    return;
  }
  const cats = result.data.categories || [];
  select.innerHTML = cats.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
}

document.getElementById('loadNewsBtn').addEventListener('click', async () => {
  const sourceId = document.getElementById('newsSource').value;
  const category = document.getElementById('newsCategory').value;
  const container = document.getElementById('newsList');
  container.innerHTML = '<div class="empty">加载中...</div>';
  
  const result = await api(`/news/list?source_id=${sourceId}&category=${encodeURIComponent(category)}&page=1&limit=20`);
  if (result.code !== 0) {
    container.innerHTML = `<div class="empty">${result.msg || '加载失败'}</div>`;
    return;
  }
  const news = (result.data && result.data.news) || [];
  if (news.length === 0) {
    container.innerHTML = '<div class="empty">暂无数据</div>';
    return;
  }
  container.innerHTML = news.map((item, i) => renderNewsItem(item, i)).join('');
  attachNewsItemHandlers(container);
});

// 搜索
document.getElementById('searchBtn').addEventListener('click', async () => {
  const keyword = document.getElementById('searchInput').value.trim();
  const sourceId = document.getElementById('searchSource').value;
  
  if (!keyword) {
    showToast('请输入关键词', 'error');
    return;
  }
  
  const container = document.getElementById('searchResults');
  container.innerHTML = '<div class="empty">搜索中...</div>';
  
  const result = await api('/search', {
    method: 'POST',
    body: JSON.stringify({ keyword, source_id: sourceId, page: 1, page_size: 30 }),
  });
  
  if (result.code !== 0) {
    container.innerHTML = `<div class="empty">${result.msg || '搜索失败'}</div>`;
    return;
  }
  const news = result.data?.results || [];
  if (news.length === 0) {
    container.innerHTML = '<div class="empty">未找到相关结果</div>';
    return;
  }
  container.innerHTML = news.map((item, i) => renderNewsItem(item, i)).join('');
  attachNewsItemHandlers(container);
});

document.getElementById('searchInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('searchBtn').click();
});

// 可播放新闻
async function loadPlayableNews() {
  const container = document.getElementById('playableList');
  container.innerHTML = '<div class="empty">加载中...</div>';
  
  const result = await api('/player/playable?limit=30');
  if (result.code !== 0) {
    container.innerHTML = `<div class="empty">${result.msg || '加载失败'}</div>`;
    return;
  }
  
  const news = result.data?.news || [];
  if (news.length === 0) {
    container.innerHTML = '<div class="empty">暂无新闻</div>';
    return;
  }
  
  container.innerHTML = news.map((item, i) => renderNewsItem(item, i)).join('');
  attachNewsItemHandlers(container);
}

document.getElementById('playAllBtn').addEventListener('click', async () => {
  const result = await api('/player/playable?limit=20');
  if (result.code !== 0 || !result.data?.news) {
    showToast('加载失败', 'error');
    return;
  }
  const mode = document.getElementById('playerMode').value;
  player.setTtsMode(mode);
  player.setQueue(result.data.news, 0);
  showToast('开始播放', 'success');
});

document.getElementById('playerMode').addEventListener('change', (e) => {
  player.setTtsMode(e.target.value);
  updateModeDisplay();
});

function updateModeDisplay() {
  const mode = document.getElementById('playerMode').value;
  const display = document.getElementById('playerModeDisplay');
  const modeMap = {
    auto: '🔊 自动模式（优先音频）',
    audio: '🎵 仅音频模式',
    tts: '📖 TTS 朗读模式',
  };
  display.textContent = modeMap[mode] || '';
}

// 播放列表
async function loadPlaylist() {
  const result = await api('/player/playlist');
  if (result.code !== 0) {
    showToast('加载失败', 'error');
    return;
  }
  const list = result.data?.items || [];
  document.getElementById('playlistCount').textContent = `${list.length} 首`;
  
  const container = document.getElementById('playlistList');
  if (list.length === 0) {
    container.innerHTML = '<div class="empty">播放列表为空</div>';
    return;
  }
  
  container.innerHTML = list.map((item, i) => renderNewsItem(item, i)).join('');
  attachPlaylistHandlers(container, list);
}

function attachPlaylistHandlers(container, list) {
  container.querySelectorAll('.news-item').forEach((el, i) => {
    el.addEventListener('click', (e) => {
      if (e.target.closest('.play-actions')) return;
      // 点击播放此项
      const item = list[i];
      player.setTtsMode('auto');
      player.setQueue(list, i);
    });
    
    el.querySelectorAll('.play-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const action = btn.dataset.action;
        const item = list[i];
        
        if (action === 'play-audio') {
          player.setTtsMode('audio');
          player.setQueue([item], 0);
        } else if (action === 'play-tts') {
          player.setTtsMode('tts');
          player.setQueue([item], 0);
        } else if (action === 'add-playlist') {
          // 移除
          const result = await api(`/player/playlist/remove?id=${encodeURIComponent(item.id)}&source=${encodeURIComponent(item.source)}`, {
            method: 'DELETE',
          });
          if (result.code === 0) {
            showToast('已移除', 'success');
            loadPlaylist();
          }
        }
      });
    });
  });
}

document.getElementById('playPlaylistBtn').addEventListener('click', () => {
  if (player.queue.length === 0) {
    showToast('播放列表为空', 'error');
    return;
  }
  player.setQueue(player.queue, 0);
  showToast('开始播放列表', 'success');
});

document.getElementById('clearPlaylistBtn').addEventListener('click', async () => {
  if (!confirm('确认清空播放列表？')) return;
  const result = await api('/player/playlist/clear?listName=default', { method: 'DELETE' });
  if (result.code === 0) {
    showToast('已清空', 'success');
    loadPlaylist();
  }
});

// 脚本管理
async function loadSourceList() {
  const result = await api('/custom-sources');
  const list = document.getElementById('sourceList');
  if (result.code !== 0 || !result.data) {
    list.innerHTML = '<div class="empty">加载失败</div>';
    return;
  }
  const sources = result.data.sources || [];
  if (sources.length === 0) {
    list.innerHTML = '<div class="empty">尚未导入任何自定义脚本</div>';
    return;
  }
  list.innerHTML = sources.map(s => `
    <div class="source-item" data-id="${escapeHtml(s.id)}">
      <label class="switch">
        <input type="checkbox" ${s.enabled ? 'checked' : ''}>
        <span class="slider"></span>
      </label>
      <div class="source-info">
        <div class="source-name">${escapeHtml(s.name)} <small>v${escapeHtml(s.version || '1.0.0')}</small></div>
        <div class="source-meta">
          作者: ${escapeHtml(s.author || '未知')} | 
          平台: ${(s.platforms || []).map(escapeHtml).join(', ') || '通用'} | 
          ${formatTime(s.updateTime)}
        </div>
        ${s.description ? `<div class="source-meta">${escapeHtml(s.description)}</div>` : ''}
      </div>
      <div class="source-actions">
        <button class="delete-btn danger">删除</button>
      </div>
    </div>
  `).join('');
  
  list.querySelectorAll('.source-item').forEach(item => {
    const id = item.dataset.id;
    const switchInput = item.querySelector('input[type="checkbox"]');
    switchInput.addEventListener('change', async () => {
      const result = await api('/custom-sources/toggle', {
        method: 'PUT',
        body: JSON.stringify({ id, enabled: switchInput.checked }),
      });
      if (result.code === 0) {
        showToast(switchInput.checked ? '已启用' : '已禁用', 'success');
      } else {
        switchInput.checked = !switchInput.checked;
        showToast('操作失败', 'error');
      }
    });
    item.querySelector('.delete-btn').addEventListener('click', async () => {
      if (!confirm('确认删除此脚本？')) return;
      const result = await api(`/custom-sources?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
      if (result.code === 0) {
        showToast('已删除', 'success');
        loadSourceList();
      } else {
        showToast('删除失败', 'error');
      }
    });
  });
}

document.getElementById('importScriptBtn').addEventListener('click', async () => {
  const name = document.getElementById('scriptName').value.trim() || 'imported';
  const content = document.getElementById('scriptContent').value.trim();
  if (!content) {
    showToast('请输入脚本内容', 'error');
    return;
  }
  const result = await api('/custom-sources/import', {
    method: 'POST',
    body: JSON.stringify({ name, content }),
  });
  if (result.code === 0) {
    showToast('导入成功', 'success');
    document.getElementById('scriptContent').value = '';
    document.getElementById('scriptName').value = '';
    loadSourceList();
  } else {
    showToast('导入失败: ' + (result.msg || ''), 'error');
  }
});

document.getElementById('importUrlBtn').addEventListener('click', async () => {
  const url = document.getElementById('scriptUrl').value.trim();
  if (!url) {
    showToast('请输入 URL', 'error');
    return;
  }
  showToast('导入中...', 'info');
  const result = await api('/custom-sources/import-url', {
    method: 'POST',
    body: JSON.stringify({ url }),
  });
  if (result.code === 0) {
    showToast('导入成功', 'success');
    document.getElementById('scriptUrl').value = '';
    loadSourceList();
  } else {
    showToast('导入失败: ' + (result.msg || ''), 'error');
  }
});

document.getElementById('reloadSourcesBtn').addEventListener('click', async () => {
  const result = await api('/custom-sources/reload', { method: 'POST' });
  if (result.code === 0) {
    showToast('已重新加载', 'success');
    loadSourceList();
  } else {
    showToast('重载失败', 'error');
  }
});

// ============= 播放器控制 =============

function setupPlayer() {
  player = new NewsPlayer();
  
  const playerPanel = document.getElementById('playerPanel');
  const playerTitle = document.getElementById('playerTitle');
  const playerSubtitle = document.getElementById('playerSubtitle');
  const playerCover = document.getElementById('playerCover');
  const playerIcon = document.getElementById('playerIcon');
  const playerPlayBtn = document.getElementById('playerPlayBtn');
  const playerPrevBtn = document.getElementById('playerPrevBtn');
  const playerNextBtn = document.getElementById('playerNextBtn');
  const playerModeBtn = document.getElementById('playerModeBtn');
  const playerCloseBtn = document.getElementById('playerCloseBtn');
  const playerVolumeBtn = document.getElementById('playerVolumeBtn');
  const playerVolumePopup = document.getElementById('playerVolumePopup');
  const playerVolumeRange = document.getElementById('playerVolumeRange');
  const playerRate = document.getElementById('playerRate');
  const playerProgressBar = document.getElementById('playerProgressBar');
  const playerProgressFill = document.getElementById('playerProgressFill');
  const playerCurrentTime = document.getElementById('playerCurrentTime');
  const playerDuration = document.getElementById('playerDuration');
  
  function updateUI() {
    const state = player.getState();
    if (state.currentItem) {
      playerPanel.classList.add('active');
      playerTitle.textContent = state.currentItem.title || '未知';
      playerSubtitle.textContent = `${state.currentItem.sourceName || state.currentItem.source} · ${formatTime(state.currentItem.publishTime)}`;
      if (state.currentItem.cover) {
        playerCover.src = state.currentItem.cover;
        playerCover.style.display = 'block';
      } else {
        playerCover.style.display = 'none';
      }
    } else {
      playerPanel.classList.remove('active');
    }
    playerPlayBtn.textContent = state.isPlaying ? '⏸' : '▶';
    
    // 高亮正在播放的卡片
    document.querySelectorAll('.news-item.playing').forEach(el => el.classList.remove('playing'));
    if (state.currentItem) {
      const el = document.querySelector(`.news-item[data-id="${state.currentItem.id}"][data-source="${state.currentItem.source}"]`);
      if (el) el.classList.add('playing');
    }
  }
  
  player.on('itemchange', updateUI);
  player.on('play', updateUI);
  player.on('pause', updateUI);
  player.on('stop', updateUI);
  player.on('ttsmodechange', updateModeDisplay);
  
  player.on('timeupdate', (data) => {
    playerCurrentTime.textContent = formatDuration(data.currentTime);
    playerDuration.textContent = formatDuration(data.duration);
    playerProgressFill.style.width = (data.progress * 100) + '%';
  });
  
  player.on('loadedmetadata', (data) => {
    playerDuration.textContent = formatDuration(data.duration);
  });
  
  playerPlayBtn.addEventListener('click', () => player.toggle());
  playerPrevBtn.addEventListener('click', () => player.prev());
  playerNextBtn.addEventListener('click', () => player.next());
  playerCloseBtn.addEventListener('click', () => {
    player.stop();
    playerPanel.classList.remove('active');
  });
  
  const playModes = ['queue', 'loop', 'single'];
  const modeIcons = { queue: '🔁', loop: '🔂', single: '1️⃣' };
  playerModeBtn.addEventListener('click', () => {
    const idx = playModes.indexOf(player.playMode);
    const next = playModes[(idx + 1) % playModes.length];
    player.setPlayMode(next);
    playerModeBtn.textContent = modeIcons[next] || '🔁';
    showToast(`播放模式：${next === 'queue' ? '列表循环' : next === 'loop' ? '单曲循环' : '单曲'}`, 'info');
  });
  
  playerVolumeBtn.addEventListener('click', () => {
    playerVolumePopup.classList.toggle('active');
  });
  
  playerVolumeRange.addEventListener('input', (e) => {
    player.setVolume(Number(e.target.value) / 100);
  });
  
  playerRate.addEventListener('change', (e) => {
    player.setRate(Number(e.target.value));
  });
  
  playerProgressBar.addEventListener('click', (e) => {
    const rect = playerProgressBar.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    player.seek(x);
  });
  
  updateModeDisplay();
}

// 全局 toast 函数
window.songloftToast = showToast;

// 启动
setupPlayer();
loadHotboard();
